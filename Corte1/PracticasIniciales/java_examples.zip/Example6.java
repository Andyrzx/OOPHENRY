// Program to print numbers from 1 to 5 
class Example6 { 
  public static void main(String[] args) { 
    int n = 5; 
    for (int i = 1; i <= n; ++i) { 
      System.out.println(i); 
    } 
  } 
} 
