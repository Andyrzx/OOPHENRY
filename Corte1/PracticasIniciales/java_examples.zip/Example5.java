// Program to print a text 5 times 
class Example5 { 
  public static void main(String[] args) { 
    int n = 5; 
    for (int i = 1; i <= n; ++i) { 
      System.out.println("Java is fun"); 
    } 
  } 
} 
