// Program to display numbers from 1 to 5 
class Example1 { 
  public static void main(String[] args) { 
    int i = 1, n = 5; 
    while(i <= n) { 
      System.out.println(i); 
      i++; 
    } 
  } 
} 
