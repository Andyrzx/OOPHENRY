// Java Program to display numbers from 1 to 5 
class Example3 { 
  public static void main(String[] args) { 
    int i = 1, n = 5; 
    do { 
      System.out.println(i); 
      i++; 
    } while(i <= n); 
  } 
} 
